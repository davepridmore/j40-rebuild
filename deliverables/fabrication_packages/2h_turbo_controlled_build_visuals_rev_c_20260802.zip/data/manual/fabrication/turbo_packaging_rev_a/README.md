# J40 2H Turbo Engine-Bay Packaging Study — Rev A

Purpose: put every currently known engine-bay component into one relocation-control list before permanent turbo, intake, charge-air, exhaust, cooling or electrical brackets are made.

The companion image is an illustrative packaging mock-up only:

- `docs/images/turbo-2h-controlled-build/05-rev-h-radiator-battery-electrical-packaging.png`

Image 05 supersedes image 04 for current layout discussion because it includes the Rev H radiator/shroud, the chassis-supported DLS120 carrier and the independent Relay Rev D/MIDI Rev D packages. Image 04 remains retained as visual history.

The controlling working file is:

- `engine_bay_component_relocation_matrix.csv`

## How to use the matrix

1. Fit or rigidly mock every `RETAIN/FREEZE` component first.
2. Make full-size cardboard/foamboard envelopes for every `MOVE`, `ADD` or `HOLD` item.
3. Mark the bonnet, wing, chassis, firewall and radiator planes as fixed datums.
4. Record the current and proposed XYZ envelope, service-removal path and movement allowance on the vehicle.
5. Resolve every `DECISION HOLD` and `MEASUREMENT HOLD` before drilling, welding, crimping final hoses or making final pipes.

The rendered image is deliberately non-dimensional. It suggests a way to make all envelopes visible at once; it does not approve any depicted location.

## Current high-priority decisions

- The existing large round air cleaner occupies valuable rear/side bay volume and is the clearest planned relocation.
- Steering box, shaft, pump, reservoir and hoses control the turbo/downpipe corridor and must be frozen first.
- The battery remains in its known pocket on a chassis-supported stand; only the protected cutoff/breaker stays battery-side.
- Relay Rev D and MIDI Rev D move off the superseded battery ladder. Rev H requires two independent, high/rear structural brackets, vertically/depth staggered and not attached to the radiator or its side rails.
- Charge-cooler location is unresolved: the turbo option sheet specifies a separate side/wing cooler, while the Rev H cooling-pack specification includes a `500 x 180 x 50 mm` front cooler. Do not fabricate either route until one system architecture is signed.
