# 2H Controlled Turbo Build Visuals

Generated planning visuals for `docs/2h-turbo-recommended-build-process-20260801.md`.

These images are process and packaging aids only. They are not dimensional drawings, as-built records, component-identification evidence or authority to fabricate. Physical parts and measured vehicle clearances control every release gate.

Included assets:

- `01-package-receipt-inspection.png` — Stage 3 goods-receipt and identity-control concept.
- `02-full-engine-bay-mockup.png` — Stages 4–6 full-vehicle mock-up and clearance concept.
- `03-static-commissioning.png` — Stages 10–12 static test and monitoring concept.
- `04-known-components-relocation-study.png` — fuller retained/new component packaging study used with the relocation matrix.
- `05-rev-h-radiator-battery-electrical-packaging.png` — earlier Rev H relocation study using cardboard component envelopes; retained as visual history.
- `06-real-components-rev-h-packaging-near-side.png` — current near-side packaging study using the photographed round steel air cleaner, DLS120 battery, cutoff, relay enclosure and MIDI fuse bank. It removes the unused compact-air-cleaner alternative and provisional side/wing cooler because charge cooling is contained in the Rev H front stack.
- `07-real-components-rev-h-packaging-opposite-side.png` — paired opposite-side view of the same controlled layout, generated as a camera move rather than a mirrored image.

Images 06 and 07 are the current paired visual authority for layout discussions. Images 04 and 05 remain available to show the development history.

Generation mode: OpenAI built-in image generation.

The source prompt set is recorded in `generation-prompts.md`.
