# 2H Controlled Turbo Build Visuals

Generated planning visuals for `docs/2h-turbo-recommended-build-process-20260801.md`.

These images are process and packaging aids only. They are not dimensional drawings, as-built records, component-identification evidence or authority to fabricate. Physical parts and measured vehicle clearances control every release gate.

Included assets:

- `01-package-receipt-inspection.png` — Stage 3 goods-receipt and identity-control concept.
- `02-full-engine-bay-mockup.png` — Stages 4–6 full-vehicle mock-up and clearance concept.
- `03-static-commissioning.png` — Stages 10–12 static test and monitoring concept.
- `04-known-components-relocation-study.png` — fuller retained/new component packaging study used with the relocation matrix.

Generation mode: OpenAI built-in image generation.

The source prompt set is recorded in `generation-prompts.md`.
